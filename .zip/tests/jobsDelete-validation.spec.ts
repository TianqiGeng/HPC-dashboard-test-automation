import { test, expect, type Page } from '@playwright/test';


async function openJobsPage(page: Page) {
  await page.goto('/');
  await page.getByText('Jobs', { exact: true }).click();

  await expect( page.getByRole('button', { name: 'Export JSON' }) ).toBeVisible();
}


test('Cleanup test jobs', async ({ page }) => {
  await openJobsPage(page);

  await expect(
    page.getByText(/^playwright-job-/).first()
  ).toBeVisible({ timeout: 15000 });

  while (await page.getByText(/^playwright-job-/).count() > 0) {
    const job = page.getByText(/^playwright-job-/).first();
    const jobName = (await job.innerText()).trim();

    const card = job.locator(
      'xpath=ancestor::*[.//button[@aria-label]][1]'
    );

    await card.locator(
      'button[aria-label^="Open actions for "]'
    ).click();

    await page.getByText('Delete Job', { exact: true }).click();

    
    await expect(
      page.getByText(jobName, { exact: true })
    ).toHaveCount(0, { timeout: 15000 });

    console.log('Deleted:', jobName);
  }
});